# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "BUILD_ID" -parent ${Page_0}
  ipgui::add_param $IPINST -name "NX_MAX" -parent ${Page_0}
  ipgui::add_param $IPINST -name "NZ_MAX" -parent ${Page_0}


}

proc update_PARAM_VALUE.BUILD_ID { PARAM_VALUE.BUILD_ID } {
	# Procedure called to update BUILD_ID when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.BUILD_ID { PARAM_VALUE.BUILD_ID } {
	# Procedure called to validate BUILD_ID
	return true
}

proc update_PARAM_VALUE.NX_MAX { PARAM_VALUE.NX_MAX } {
	# Procedure called to update NX_MAX when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.NX_MAX { PARAM_VALUE.NX_MAX } {
	# Procedure called to validate NX_MAX
	return true
}

proc update_PARAM_VALUE.NZ_MAX { PARAM_VALUE.NZ_MAX } {
	# Procedure called to update NZ_MAX when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.NZ_MAX { PARAM_VALUE.NZ_MAX } {
	# Procedure called to validate NZ_MAX
	return true
}


proc update_MODELPARAM_VALUE.BUILD_ID { MODELPARAM_VALUE.BUILD_ID PARAM_VALUE.BUILD_ID } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.BUILD_ID}] ${MODELPARAM_VALUE.BUILD_ID}
}

proc update_MODELPARAM_VALUE.NX_MAX { MODELPARAM_VALUE.NX_MAX PARAM_VALUE.NX_MAX } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.NX_MAX}] ${MODELPARAM_VALUE.NX_MAX}
}

proc update_MODELPARAM_VALUE.NZ_MAX { MODELPARAM_VALUE.NZ_MAX PARAM_VALUE.NZ_MAX } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.NZ_MAX}] ${MODELPARAM_VALUE.NZ_MAX}
}

