//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Sun Oct 18 00:11:36 2026
//Host        : DESKTOP-KTJ622C running 64-bit major release  (build 9200)
//Command     : generate_target system.bd
//Design      : system
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "system,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=system,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=11,numReposBlks=11,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=1,numPkgbdBlks=0,bdsource=USER,da_zynq_ultra_ps_e_cnt=1,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "system.hwdef" *) 
module system
   (clk_link,
    clk_sem,
    gt_cplllock,
    gt_loopback,
    gt_powergood,
    gt_prbs_cnt_reset,
    gt_prbs_force_err,
    gt_prbs_sel,
    gt_reset_all,
    gt_reset_rx,
    gt_rx_done,
    gt_rxbufreset,
    gt_rxbufstatus,
    gt_rxbyteisaligned,
    gt_rxcharisk,
    gt_rxclkcorcnt,
    gt_rxdata,
    gt_rxdisperr,
    gt_rxnotintable,
    gt_rxpolarity,
    gt_rxprbserr,
    gt_rxprbslocked,
    gt_tx_done,
    gt_txcharisk,
    gt_txdata,
    gt_txpolarity,
    sem_cmd_busy,
    sem_cmd_code,
    sem_cmd_strobe,
    sem_grant,
    sem_icap_avail,
    sem_mon_data,
    sem_mon_write,
    sem_status,
    sfp_tx_enable);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK_LINK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK_LINK, CLK_DOMAIN system_clk_link, FREQ_HZ 62500000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input clk_link;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK_SEM CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK_SEM, CLK_DOMAIN system_clk_sem, FREQ_HZ 31250000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input clk_sem;
  input [1:0]gt_cplllock;
  output [2:0]gt_loopback;
  input [1:0]gt_powergood;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.GT_PRBS_CNT_RESET RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.GT_PRBS_CNT_RESET, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) output gt_prbs_cnt_reset;
  output gt_prbs_force_err;
  output [3:0]gt_prbs_sel;
  output gt_reset_all;
  output gt_reset_rx;
  input gt_rx_done;
  output [1:0]gt_rxbufreset;
  input [5:0]gt_rxbufstatus;
  input [1:0]gt_rxbyteisaligned;
  input [3:0]gt_rxcharisk;
  input [3:0]gt_rxclkcorcnt;
  input [31:0]gt_rxdata;
  input [3:0]gt_rxdisperr;
  input [3:0]gt_rxnotintable;
  output gt_rxpolarity;
  input [1:0]gt_rxprbserr;
  input [1:0]gt_rxprbslocked;
  input gt_tx_done;
  output [1:0]gt_txcharisk;
  output [15:0]gt_txdata;
  output gt_txpolarity;
  input sem_cmd_busy;
  output [43:0]sem_cmd_code;
  output sem_cmd_strobe;
  output sem_grant;
  input sem_icap_avail;
  input [7:0]sem_mon_data;
  input sem_mon_write;
  input [9:0]sem_status;
  output [1:0]sfp_tx_enable;

  wire clk_link;
  wire clk_sem;
  wire clk_sensor_gen_clk_sensor;
  wire clk_sensor_gen_locked;
  wire [127:0]dma_M_AXIS_MM2S_TDATA;
  wire dma_M_AXIS_MM2S_TLAST;
  wire dma_M_AXIS_MM2S_TREADY;
  wire dma_M_AXIS_MM2S_TVALID;
  wire [31:0]dma_M_AXI_MM2S_ARADDR;
  wire [1:0]dma_M_AXI_MM2S_ARBURST;
  wire [3:0]dma_M_AXI_MM2S_ARCACHE;
  wire [7:0]dma_M_AXI_MM2S_ARLEN;
  wire [2:0]dma_M_AXI_MM2S_ARPROT;
  wire dma_M_AXI_MM2S_ARREADY;
  wire [2:0]dma_M_AXI_MM2S_ARSIZE;
  wire dma_M_AXI_MM2S_ARVALID;
  wire [127:0]dma_M_AXI_MM2S_RDATA;
  wire dma_M_AXI_MM2S_RLAST;
  wire dma_M_AXI_MM2S_RREADY;
  wire [1:0]dma_M_AXI_MM2S_RRESP;
  wire dma_M_AXI_MM2S_RVALID;
  wire [31:0]dma_M_AXI_S2MM_AWADDR;
  wire [1:0]dma_M_AXI_S2MM_AWBURST;
  wire [3:0]dma_M_AXI_S2MM_AWCACHE;
  wire [7:0]dma_M_AXI_S2MM_AWLEN;
  wire [2:0]dma_M_AXI_S2MM_AWPROT;
  wire dma_M_AXI_S2MM_AWREADY;
  wire [2:0]dma_M_AXI_S2MM_AWSIZE;
  wire dma_M_AXI_S2MM_AWVALID;
  wire dma_M_AXI_S2MM_BREADY;
  wire [1:0]dma_M_AXI_S2MM_BRESP;
  wire dma_M_AXI_S2MM_BVALID;
  wire [127:0]dma_M_AXI_S2MM_WDATA;
  wire dma_M_AXI_S2MM_WLAST;
  wire dma_M_AXI_S2MM_WREADY;
  wire [15:0]dma_M_AXI_S2MM_WSTRB;
  wire dma_M_AXI_S2MM_WVALID;
  wire [31:0]dma_gr_M_AXI_S2MM_AWADDR;
  wire [1:0]dma_gr_M_AXI_S2MM_AWBURST;
  wire [3:0]dma_gr_M_AXI_S2MM_AWCACHE;
  wire [7:0]dma_gr_M_AXI_S2MM_AWLEN;
  wire [2:0]dma_gr_M_AXI_S2MM_AWPROT;
  wire dma_gr_M_AXI_S2MM_AWREADY;
  wire [2:0]dma_gr_M_AXI_S2MM_AWSIZE;
  wire dma_gr_M_AXI_S2MM_AWVALID;
  wire dma_gr_M_AXI_S2MM_BREADY;
  wire [1:0]dma_gr_M_AXI_S2MM_BRESP;
  wire dma_gr_M_AXI_S2MM_BVALID;
  wire [127:0]dma_gr_M_AXI_S2MM_WDATA;
  wire dma_gr_M_AXI_S2MM_WLAST;
  wire dma_gr_M_AXI_S2MM_WREADY;
  wire [15:0]dma_gr_M_AXI_S2MM_WSTRB;
  wire dma_gr_M_AXI_S2MM_WVALID;
  wire dma_gr_s2mm_introut;
  wire dma_mm2s_introut;
  wire dma_s2mm_introut;
  wire [1:0]gt_cplllock;
  wire [2:0]gt_loopback;
  wire [1:0]gt_powergood;
  wire gt_prbs_cnt_reset;
  wire gt_prbs_force_err;
  wire [3:0]gt_prbs_sel;
  wire gt_reset_all;
  wire gt_reset_rx;
  wire gt_rx_done;
  wire [1:0]gt_rxbufreset;
  wire [5:0]gt_rxbufstatus;
  wire [1:0]gt_rxbyteisaligned;
  wire [3:0]gt_rxcharisk;
  wire [3:0]gt_rxclkcorcnt;
  wire [31:0]gt_rxdata;
  wire [3:0]gt_rxdisperr;
  wire [3:0]gt_rxnotintable;
  wire gt_rxpolarity;
  wire [1:0]gt_rxprbserr;
  wire [1:0]gt_rxprbslocked;
  wire gt_tx_done;
  wire [1:0]gt_txcharisk;
  wire [15:0]gt_txdata;
  wire gt_txpolarity;
  wire hpdp_irq;
  wire [63:0]hpdp_m_axis_cmp_TDATA;
  wire [7:0]hpdp_m_axis_cmp_TKEEP;
  wire hpdp_m_axis_cmp_TLAST;
  wire hpdp_m_axis_cmp_TREADY;
  wire hpdp_m_axis_cmp_TVALID;
  wire [63:0]hpdp_m_axis_gr_TDATA;
  wire [7:0]hpdp_m_axis_gr_TKEEP;
  wire hpdp_m_axis_gr_TLAST;
  wire hpdp_m_axis_gr_TREADY;
  wire hpdp_m_axis_gr_TVALID;
  wire [3:0]irq_concat_dout;
  wire [39:0]ps_M_AXI_HPM0_FPD_ARADDR;
  wire [1:0]ps_M_AXI_HPM0_FPD_ARBURST;
  wire [3:0]ps_M_AXI_HPM0_FPD_ARCACHE;
  wire [15:0]ps_M_AXI_HPM0_FPD_ARID;
  wire [7:0]ps_M_AXI_HPM0_FPD_ARLEN;
  wire ps_M_AXI_HPM0_FPD_ARLOCK;
  wire [2:0]ps_M_AXI_HPM0_FPD_ARPROT;
  wire [3:0]ps_M_AXI_HPM0_FPD_ARQOS;
  wire ps_M_AXI_HPM0_FPD_ARREADY;
  wire [2:0]ps_M_AXI_HPM0_FPD_ARSIZE;
  wire [15:0]ps_M_AXI_HPM0_FPD_ARUSER;
  wire ps_M_AXI_HPM0_FPD_ARVALID;
  wire [39:0]ps_M_AXI_HPM0_FPD_AWADDR;
  wire [1:0]ps_M_AXI_HPM0_FPD_AWBURST;
  wire [3:0]ps_M_AXI_HPM0_FPD_AWCACHE;
  wire [15:0]ps_M_AXI_HPM0_FPD_AWID;
  wire [7:0]ps_M_AXI_HPM0_FPD_AWLEN;
  wire ps_M_AXI_HPM0_FPD_AWLOCK;
  wire [2:0]ps_M_AXI_HPM0_FPD_AWPROT;
  wire [3:0]ps_M_AXI_HPM0_FPD_AWQOS;
  wire ps_M_AXI_HPM0_FPD_AWREADY;
  wire [2:0]ps_M_AXI_HPM0_FPD_AWSIZE;
  wire [15:0]ps_M_AXI_HPM0_FPD_AWUSER;
  wire ps_M_AXI_HPM0_FPD_AWVALID;
  wire [15:0]ps_M_AXI_HPM0_FPD_BID;
  wire ps_M_AXI_HPM0_FPD_BREADY;
  wire [1:0]ps_M_AXI_HPM0_FPD_BRESP;
  wire ps_M_AXI_HPM0_FPD_BVALID;
  wire [31:0]ps_M_AXI_HPM0_FPD_RDATA;
  wire [15:0]ps_M_AXI_HPM0_FPD_RID;
  wire ps_M_AXI_HPM0_FPD_RLAST;
  wire ps_M_AXI_HPM0_FPD_RREADY;
  wire [1:0]ps_M_AXI_HPM0_FPD_RRESP;
  wire ps_M_AXI_HPM0_FPD_RVALID;
  wire [31:0]ps_M_AXI_HPM0_FPD_WDATA;
  wire ps_M_AXI_HPM0_FPD_WLAST;
  wire ps_M_AXI_HPM0_FPD_WREADY;
  wire [3:0]ps_M_AXI_HPM0_FPD_WSTRB;
  wire ps_M_AXI_HPM0_FPD_WVALID;
  wire ps_pl_clk0;
  wire ps_pl_clk1;
  wire ps_pl_resetn0;
  wire [0:0]rst_ctrl_interconnect_aresetn;
  wire [0:0]rst_ctrl_peripheral_aresetn;
  wire [0:0]rst_sensor_peripheral_aresetn;
  wire [0:0]rst_sys_interconnect_aresetn;
  wire [0:0]rst_sys_peripheral_aresetn;
  wire [9:0]sc_ctrl_M00_AXI_ARADDR;
  wire sc_ctrl_M00_AXI_ARREADY;
  wire sc_ctrl_M00_AXI_ARVALID;
  wire [9:0]sc_ctrl_M00_AXI_AWADDR;
  wire sc_ctrl_M00_AXI_AWREADY;
  wire sc_ctrl_M00_AXI_AWVALID;
  wire sc_ctrl_M00_AXI_BREADY;
  wire [1:0]sc_ctrl_M00_AXI_BRESP;
  wire sc_ctrl_M00_AXI_BVALID;
  wire [31:0]sc_ctrl_M00_AXI_RDATA;
  wire sc_ctrl_M00_AXI_RREADY;
  wire [1:0]sc_ctrl_M00_AXI_RRESP;
  wire sc_ctrl_M00_AXI_RVALID;
  wire [31:0]sc_ctrl_M00_AXI_WDATA;
  wire sc_ctrl_M00_AXI_WREADY;
  wire sc_ctrl_M00_AXI_WVALID;
  wire [19:0]sc_ctrl_M01_AXI_ARADDR;
  wire [2:0]sc_ctrl_M01_AXI_ARPROT;
  wire sc_ctrl_M01_AXI_ARREADY;
  wire sc_ctrl_M01_AXI_ARVALID;
  wire [19:0]sc_ctrl_M01_AXI_AWADDR;
  wire [2:0]sc_ctrl_M01_AXI_AWPROT;
  wire sc_ctrl_M01_AXI_AWREADY;
  wire sc_ctrl_M01_AXI_AWVALID;
  wire sc_ctrl_M01_AXI_BREADY;
  wire [1:0]sc_ctrl_M01_AXI_BRESP;
  wire sc_ctrl_M01_AXI_BVALID;
  wire [31:0]sc_ctrl_M01_AXI_RDATA;
  wire sc_ctrl_M01_AXI_RREADY;
  wire [1:0]sc_ctrl_M01_AXI_RRESP;
  wire sc_ctrl_M01_AXI_RVALID;
  wire [31:0]sc_ctrl_M01_AXI_WDATA;
  wire sc_ctrl_M01_AXI_WREADY;
  wire [3:0]sc_ctrl_M01_AXI_WSTRB;
  wire sc_ctrl_M01_AXI_WVALID;
  wire [9:0]sc_ctrl_M02_AXI_ARADDR;
  wire sc_ctrl_M02_AXI_ARREADY;
  wire sc_ctrl_M02_AXI_ARVALID;
  wire [9:0]sc_ctrl_M02_AXI_AWADDR;
  wire sc_ctrl_M02_AXI_AWREADY;
  wire sc_ctrl_M02_AXI_AWVALID;
  wire sc_ctrl_M02_AXI_BREADY;
  wire [1:0]sc_ctrl_M02_AXI_BRESP;
  wire sc_ctrl_M02_AXI_BVALID;
  wire [31:0]sc_ctrl_M02_AXI_RDATA;
  wire sc_ctrl_M02_AXI_RREADY;
  wire [1:0]sc_ctrl_M02_AXI_RRESP;
  wire sc_ctrl_M02_AXI_RVALID;
  wire [31:0]sc_ctrl_M02_AXI_WDATA;
  wire sc_ctrl_M02_AXI_WREADY;
  wire sc_ctrl_M02_AXI_WVALID;
  wire [48:0]sc_data_M00_AXI_ARADDR;
  wire [1:0]sc_data_M00_AXI_ARBURST;
  wire [3:0]sc_data_M00_AXI_ARCACHE;
  wire [7:0]sc_data_M00_AXI_ARLEN;
  wire [0:0]sc_data_M00_AXI_ARLOCK;
  wire [2:0]sc_data_M00_AXI_ARPROT;
  wire [3:0]sc_data_M00_AXI_ARQOS;
  wire sc_data_M00_AXI_ARREADY;
  wire [2:0]sc_data_M00_AXI_ARSIZE;
  wire sc_data_M00_AXI_ARVALID;
  wire [48:0]sc_data_M00_AXI_AWADDR;
  wire [1:0]sc_data_M00_AXI_AWBURST;
  wire [3:0]sc_data_M00_AXI_AWCACHE;
  wire [7:0]sc_data_M00_AXI_AWLEN;
  wire [0:0]sc_data_M00_AXI_AWLOCK;
  wire [2:0]sc_data_M00_AXI_AWPROT;
  wire [3:0]sc_data_M00_AXI_AWQOS;
  wire sc_data_M00_AXI_AWREADY;
  wire [2:0]sc_data_M00_AXI_AWSIZE;
  wire sc_data_M00_AXI_AWVALID;
  wire sc_data_M00_AXI_BREADY;
  wire [1:0]sc_data_M00_AXI_BRESP;
  wire sc_data_M00_AXI_BVALID;
  wire [127:0]sc_data_M00_AXI_RDATA;
  wire sc_data_M00_AXI_RLAST;
  wire sc_data_M00_AXI_RREADY;
  wire [1:0]sc_data_M00_AXI_RRESP;
  wire sc_data_M00_AXI_RVALID;
  wire [127:0]sc_data_M00_AXI_WDATA;
  wire sc_data_M00_AXI_WLAST;
  wire sc_data_M00_AXI_WREADY;
  wire [15:0]sc_data_M00_AXI_WSTRB;
  wire sc_data_M00_AXI_WVALID;
  wire sem_cmd_busy;
  wire [43:0]sem_cmd_code;
  wire sem_cmd_strobe;
  wire sem_grant;
  wire sem_icap_avail;
  wire [7:0]sem_mon_data;
  wire sem_mon_write;
  wire [9:0]sem_status;
  wire [1:0]sfp_tx_enable;

  system_clk_sensor_gen_0 clk_sensor_gen
       (.clk_in1(ps_pl_clk0),
        .clk_sensor(clk_sensor_gen_clk_sensor),
        .locked(clk_sensor_gen_locked),
        .resetn(ps_pl_resetn0));
  system_dma_0 dma
       (.axi_resetn(rst_ctrl_peripheral_aresetn),
        .m_axi_mm2s_aclk(ps_pl_clk1),
        .m_axi_mm2s_araddr(dma_M_AXI_MM2S_ARADDR),
        .m_axi_mm2s_arburst(dma_M_AXI_MM2S_ARBURST),
        .m_axi_mm2s_arcache(dma_M_AXI_MM2S_ARCACHE),
        .m_axi_mm2s_arlen(dma_M_AXI_MM2S_ARLEN),
        .m_axi_mm2s_arprot(dma_M_AXI_MM2S_ARPROT),
        .m_axi_mm2s_arready(dma_M_AXI_MM2S_ARREADY),
        .m_axi_mm2s_arsize(dma_M_AXI_MM2S_ARSIZE),
        .m_axi_mm2s_arvalid(dma_M_AXI_MM2S_ARVALID),
        .m_axi_mm2s_rdata(dma_M_AXI_MM2S_RDATA),
        .m_axi_mm2s_rlast(dma_M_AXI_MM2S_RLAST),
        .m_axi_mm2s_rready(dma_M_AXI_MM2S_RREADY),
        .m_axi_mm2s_rresp(dma_M_AXI_MM2S_RRESP),
        .m_axi_mm2s_rvalid(dma_M_AXI_MM2S_RVALID),
        .m_axi_s2mm_aclk(ps_pl_clk1),
        .m_axi_s2mm_awaddr(dma_M_AXI_S2MM_AWADDR),
        .m_axi_s2mm_awburst(dma_M_AXI_S2MM_AWBURST),
        .m_axi_s2mm_awcache(dma_M_AXI_S2MM_AWCACHE),
        .m_axi_s2mm_awlen(dma_M_AXI_S2MM_AWLEN),
        .m_axi_s2mm_awprot(dma_M_AXI_S2MM_AWPROT),
        .m_axi_s2mm_awready(dma_M_AXI_S2MM_AWREADY),
        .m_axi_s2mm_awsize(dma_M_AXI_S2MM_AWSIZE),
        .m_axi_s2mm_awvalid(dma_M_AXI_S2MM_AWVALID),
        .m_axi_s2mm_bready(dma_M_AXI_S2MM_BREADY),
        .m_axi_s2mm_bresp(dma_M_AXI_S2MM_BRESP),
        .m_axi_s2mm_bvalid(dma_M_AXI_S2MM_BVALID),
        .m_axi_s2mm_wdata(dma_M_AXI_S2MM_WDATA),
        .m_axi_s2mm_wlast(dma_M_AXI_S2MM_WLAST),
        .m_axi_s2mm_wready(dma_M_AXI_S2MM_WREADY),
        .m_axi_s2mm_wstrb(dma_M_AXI_S2MM_WSTRB),
        .m_axi_s2mm_wvalid(dma_M_AXI_S2MM_WVALID),
        .m_axis_mm2s_tdata(dma_M_AXIS_MM2S_TDATA),
        .m_axis_mm2s_tlast(dma_M_AXIS_MM2S_TLAST),
        .m_axis_mm2s_tready(dma_M_AXIS_MM2S_TREADY),
        .m_axis_mm2s_tvalid(dma_M_AXIS_MM2S_TVALID),
        .mm2s_introut(dma_mm2s_introut),
        .s2mm_introut(dma_s2mm_introut),
        .s_axi_lite_aclk(ps_pl_clk0),
        .s_axi_lite_araddr(sc_ctrl_M00_AXI_ARADDR),
        .s_axi_lite_arready(sc_ctrl_M00_AXI_ARREADY),
        .s_axi_lite_arvalid(sc_ctrl_M00_AXI_ARVALID),
        .s_axi_lite_awaddr(sc_ctrl_M00_AXI_AWADDR),
        .s_axi_lite_awready(sc_ctrl_M00_AXI_AWREADY),
        .s_axi_lite_awvalid(sc_ctrl_M00_AXI_AWVALID),
        .s_axi_lite_bready(sc_ctrl_M00_AXI_BREADY),
        .s_axi_lite_bresp(sc_ctrl_M00_AXI_BRESP),
        .s_axi_lite_bvalid(sc_ctrl_M00_AXI_BVALID),
        .s_axi_lite_rdata(sc_ctrl_M00_AXI_RDATA),
        .s_axi_lite_rready(sc_ctrl_M00_AXI_RREADY),
        .s_axi_lite_rresp(sc_ctrl_M00_AXI_RRESP),
        .s_axi_lite_rvalid(sc_ctrl_M00_AXI_RVALID),
        .s_axi_lite_wdata(sc_ctrl_M00_AXI_WDATA),
        .s_axi_lite_wready(sc_ctrl_M00_AXI_WREADY),
        .s_axi_lite_wvalid(sc_ctrl_M00_AXI_WVALID),
        .s_axis_s2mm_tdata(hpdp_m_axis_cmp_TDATA),
        .s_axis_s2mm_tkeep(hpdp_m_axis_cmp_TKEEP),
        .s_axis_s2mm_tlast(hpdp_m_axis_cmp_TLAST),
        .s_axis_s2mm_tready(hpdp_m_axis_cmp_TREADY),
        .s_axis_s2mm_tvalid(hpdp_m_axis_cmp_TVALID));
  system_dma_gr_0 dma_gr
       (.axi_resetn(rst_ctrl_peripheral_aresetn),
        .m_axi_s2mm_aclk(ps_pl_clk1),
        .m_axi_s2mm_awaddr(dma_gr_M_AXI_S2MM_AWADDR),
        .m_axi_s2mm_awburst(dma_gr_M_AXI_S2MM_AWBURST),
        .m_axi_s2mm_awcache(dma_gr_M_AXI_S2MM_AWCACHE),
        .m_axi_s2mm_awlen(dma_gr_M_AXI_S2MM_AWLEN),
        .m_axi_s2mm_awprot(dma_gr_M_AXI_S2MM_AWPROT),
        .m_axi_s2mm_awready(dma_gr_M_AXI_S2MM_AWREADY),
        .m_axi_s2mm_awsize(dma_gr_M_AXI_S2MM_AWSIZE),
        .m_axi_s2mm_awvalid(dma_gr_M_AXI_S2MM_AWVALID),
        .m_axi_s2mm_bready(dma_gr_M_AXI_S2MM_BREADY),
        .m_axi_s2mm_bresp(dma_gr_M_AXI_S2MM_BRESP),
        .m_axi_s2mm_bvalid(dma_gr_M_AXI_S2MM_BVALID),
        .m_axi_s2mm_wdata(dma_gr_M_AXI_S2MM_WDATA),
        .m_axi_s2mm_wlast(dma_gr_M_AXI_S2MM_WLAST),
        .m_axi_s2mm_wready(dma_gr_M_AXI_S2MM_WREADY),
        .m_axi_s2mm_wstrb(dma_gr_M_AXI_S2MM_WSTRB),
        .m_axi_s2mm_wvalid(dma_gr_M_AXI_S2MM_WVALID),
        .s2mm_introut(dma_gr_s2mm_introut),
        .s_axi_lite_aclk(ps_pl_clk0),
        .s_axi_lite_araddr(sc_ctrl_M02_AXI_ARADDR),
        .s_axi_lite_arready(sc_ctrl_M02_AXI_ARREADY),
        .s_axi_lite_arvalid(sc_ctrl_M02_AXI_ARVALID),
        .s_axi_lite_awaddr(sc_ctrl_M02_AXI_AWADDR),
        .s_axi_lite_awready(sc_ctrl_M02_AXI_AWREADY),
        .s_axi_lite_awvalid(sc_ctrl_M02_AXI_AWVALID),
        .s_axi_lite_bready(sc_ctrl_M02_AXI_BREADY),
        .s_axi_lite_bresp(sc_ctrl_M02_AXI_BRESP),
        .s_axi_lite_bvalid(sc_ctrl_M02_AXI_BVALID),
        .s_axi_lite_rdata(sc_ctrl_M02_AXI_RDATA),
        .s_axi_lite_rready(sc_ctrl_M02_AXI_RREADY),
        .s_axi_lite_rresp(sc_ctrl_M02_AXI_RRESP),
        .s_axi_lite_rvalid(sc_ctrl_M02_AXI_RVALID),
        .s_axi_lite_wdata(sc_ctrl_M02_AXI_WDATA),
        .s_axi_lite_wready(sc_ctrl_M02_AXI_WREADY),
        .s_axi_lite_wvalid(sc_ctrl_M02_AXI_WVALID),
        .s_axis_s2mm_tdata(hpdp_m_axis_gr_TDATA),
        .s_axis_s2mm_tkeep(hpdp_m_axis_gr_TKEEP),
        .s_axis_s2mm_tlast(hpdp_m_axis_gr_TLAST),
        .s_axis_s2mm_tready(hpdp_m_axis_gr_TREADY),
        .s_axis_s2mm_tvalid(hpdp_m_axis_gr_TVALID));
  system_hpdp_0 hpdp
       (.clk_ctrl(ps_pl_clk0),
        .clk_link(clk_link),
        .clk_sem(clk_sem),
        .clk_sensor(clk_sensor_gen_clk_sensor),
        .clk_sys(ps_pl_clk1),
        .gt_cplllock(gt_cplllock),
        .gt_loopback(gt_loopback),
        .gt_powergood(gt_powergood),
        .gt_prbs_cnt_reset(gt_prbs_cnt_reset),
        .gt_prbs_force_err(gt_prbs_force_err),
        .gt_prbs_sel(gt_prbs_sel),
        .gt_reset_all(gt_reset_all),
        .gt_reset_rx(gt_reset_rx),
        .gt_rx_done(gt_rx_done),
        .gt_rxbufreset(gt_rxbufreset),
        .gt_rxbufstatus(gt_rxbufstatus),
        .gt_rxbyteisaligned(gt_rxbyteisaligned),
        .gt_rxcharisk(gt_rxcharisk),
        .gt_rxclkcorcnt(gt_rxclkcorcnt),
        .gt_rxdata(gt_rxdata),
        .gt_rxdisperr(gt_rxdisperr),
        .gt_rxnotintable(gt_rxnotintable),
        .gt_rxpolarity(gt_rxpolarity),
        .gt_rxprbserr(gt_rxprbserr),
        .gt_rxprbslocked(gt_rxprbslocked),
        .gt_tx_done(gt_tx_done),
        .gt_txcharisk(gt_txcharisk),
        .gt_txdata(gt_txdata),
        .gt_txpolarity(gt_txpolarity),
        .irq(hpdp_irq),
        .m_axis_cmp_tdata(hpdp_m_axis_cmp_TDATA),
        .m_axis_cmp_tkeep(hpdp_m_axis_cmp_TKEEP),
        .m_axis_cmp_tlast(hpdp_m_axis_cmp_TLAST),
        .m_axis_cmp_tready(hpdp_m_axis_cmp_TREADY),
        .m_axis_cmp_tvalid(hpdp_m_axis_cmp_TVALID),
        .m_axis_gr_tdata(hpdp_m_axis_gr_TDATA),
        .m_axis_gr_tkeep(hpdp_m_axis_gr_TKEEP),
        .m_axis_gr_tlast(hpdp_m_axis_gr_TLAST),
        .m_axis_gr_tready(hpdp_m_axis_gr_TREADY),
        .m_axis_gr_tvalid(hpdp_m_axis_gr_TVALID),
        .rst_ctrl_n(rst_ctrl_peripheral_aresetn),
        .rst_sensor_n(rst_sensor_peripheral_aresetn),
        .rst_sys_n(rst_sys_peripheral_aresetn),
        .s_axil_araddr(sc_ctrl_M01_AXI_ARADDR),
        .s_axil_arprot(sc_ctrl_M01_AXI_ARPROT),
        .s_axil_arready(sc_ctrl_M01_AXI_ARREADY),
        .s_axil_arvalid(sc_ctrl_M01_AXI_ARVALID),
        .s_axil_awaddr(sc_ctrl_M01_AXI_AWADDR),
        .s_axil_awprot(sc_ctrl_M01_AXI_AWPROT),
        .s_axil_awready(sc_ctrl_M01_AXI_AWREADY),
        .s_axil_awvalid(sc_ctrl_M01_AXI_AWVALID),
        .s_axil_bready(sc_ctrl_M01_AXI_BREADY),
        .s_axil_bresp(sc_ctrl_M01_AXI_BRESP),
        .s_axil_bvalid(sc_ctrl_M01_AXI_BVALID),
        .s_axil_rdata(sc_ctrl_M01_AXI_RDATA),
        .s_axil_rready(sc_ctrl_M01_AXI_RREADY),
        .s_axil_rresp(sc_ctrl_M01_AXI_RRESP),
        .s_axil_rvalid(sc_ctrl_M01_AXI_RVALID),
        .s_axil_wdata(sc_ctrl_M01_AXI_WDATA),
        .s_axil_wready(sc_ctrl_M01_AXI_WREADY),
        .s_axil_wstrb(sc_ctrl_M01_AXI_WSTRB),
        .s_axil_wvalid(sc_ctrl_M01_AXI_WVALID),
        .s_axis_dma_tdata(dma_M_AXIS_MM2S_TDATA),
        .s_axis_dma_tlast(dma_M_AXIS_MM2S_TLAST),
        .s_axis_dma_tready(dma_M_AXIS_MM2S_TREADY),
        .s_axis_dma_tvalid(dma_M_AXIS_MM2S_TVALID),
        .sem_cmd_busy(sem_cmd_busy),
        .sem_cmd_code(sem_cmd_code),
        .sem_cmd_strobe(sem_cmd_strobe),
        .sem_grant(sem_grant),
        .sem_icap_avail(sem_icap_avail),
        .sem_mon_data(sem_mon_data),
        .sem_mon_write(sem_mon_write),
        .sem_status(sem_status),
        .sensor_locked(clk_sensor_gen_locked),
        .sfp_tx_enable(sfp_tx_enable));
  assign irq_concat_dout = {dma_gr_s2mm_introut, hpdp_irq, dma_s2mm_introut, dma_mm2s_introut};
  system_ps_0 ps
       (.maxigp0_araddr(ps_M_AXI_HPM0_FPD_ARADDR),
        .maxigp0_arburst(ps_M_AXI_HPM0_FPD_ARBURST),
        .maxigp0_arcache(ps_M_AXI_HPM0_FPD_ARCACHE),
        .maxigp0_arid(ps_M_AXI_HPM0_FPD_ARID),
        .maxigp0_arlen(ps_M_AXI_HPM0_FPD_ARLEN),
        .maxigp0_arlock(ps_M_AXI_HPM0_FPD_ARLOCK),
        .maxigp0_arprot(ps_M_AXI_HPM0_FPD_ARPROT),
        .maxigp0_arqos(ps_M_AXI_HPM0_FPD_ARQOS),
        .maxigp0_arready(ps_M_AXI_HPM0_FPD_ARREADY),
        .maxigp0_arsize(ps_M_AXI_HPM0_FPD_ARSIZE),
        .maxigp0_aruser(ps_M_AXI_HPM0_FPD_ARUSER),
        .maxigp0_arvalid(ps_M_AXI_HPM0_FPD_ARVALID),
        .maxigp0_awaddr(ps_M_AXI_HPM0_FPD_AWADDR),
        .maxigp0_awburst(ps_M_AXI_HPM0_FPD_AWBURST),
        .maxigp0_awcache(ps_M_AXI_HPM0_FPD_AWCACHE),
        .maxigp0_awid(ps_M_AXI_HPM0_FPD_AWID),
        .maxigp0_awlen(ps_M_AXI_HPM0_FPD_AWLEN),
        .maxigp0_awlock(ps_M_AXI_HPM0_FPD_AWLOCK),
        .maxigp0_awprot(ps_M_AXI_HPM0_FPD_AWPROT),
        .maxigp0_awqos(ps_M_AXI_HPM0_FPD_AWQOS),
        .maxigp0_awready(ps_M_AXI_HPM0_FPD_AWREADY),
        .maxigp0_awsize(ps_M_AXI_HPM0_FPD_AWSIZE),
        .maxigp0_awuser(ps_M_AXI_HPM0_FPD_AWUSER),
        .maxigp0_awvalid(ps_M_AXI_HPM0_FPD_AWVALID),
        .maxigp0_bid(ps_M_AXI_HPM0_FPD_BID),
        .maxigp0_bready(ps_M_AXI_HPM0_FPD_BREADY),
        .maxigp0_bresp(ps_M_AXI_HPM0_FPD_BRESP),
        .maxigp0_bvalid(ps_M_AXI_HPM0_FPD_BVALID),
        .maxigp0_rdata(ps_M_AXI_HPM0_FPD_RDATA),
        .maxigp0_rid(ps_M_AXI_HPM0_FPD_RID),
        .maxigp0_rlast(ps_M_AXI_HPM0_FPD_RLAST),
        .maxigp0_rready(ps_M_AXI_HPM0_FPD_RREADY),
        .maxigp0_rresp(ps_M_AXI_HPM0_FPD_RRESP),
        .maxigp0_rvalid(ps_M_AXI_HPM0_FPD_RVALID),
        .maxigp0_wdata(ps_M_AXI_HPM0_FPD_WDATA),
        .maxigp0_wlast(ps_M_AXI_HPM0_FPD_WLAST),
        .maxigp0_wready(ps_M_AXI_HPM0_FPD_WREADY),
        .maxigp0_wstrb(ps_M_AXI_HPM0_FPD_WSTRB),
        .maxigp0_wvalid(ps_M_AXI_HPM0_FPD_WVALID),
        .maxihpm0_fpd_aclk(ps_pl_clk0),
        .pl_clk0(ps_pl_clk0),
        .pl_clk1(ps_pl_clk1),
        .pl_ps_irq0(irq_concat_dout),
        .pl_resetn0(ps_pl_resetn0),
        .saxigp2_araddr(sc_data_M00_AXI_ARADDR),
        .saxigp2_arburst(sc_data_M00_AXI_ARBURST),
        .saxigp2_arcache(sc_data_M00_AXI_ARCACHE),
        .saxigp2_arid({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .saxigp2_arlen(sc_data_M00_AXI_ARLEN),
        .saxigp2_arlock(sc_data_M00_AXI_ARLOCK),
        .saxigp2_arprot(sc_data_M00_AXI_ARPROT),
        .saxigp2_arqos(sc_data_M00_AXI_ARQOS),
        .saxigp2_arready(sc_data_M00_AXI_ARREADY),
        .saxigp2_arsize(sc_data_M00_AXI_ARSIZE),
        .saxigp2_aruser(1'b0),
        .saxigp2_arvalid(sc_data_M00_AXI_ARVALID),
        .saxigp2_awaddr(sc_data_M00_AXI_AWADDR),
        .saxigp2_awburst(sc_data_M00_AXI_AWBURST),
        .saxigp2_awcache(sc_data_M00_AXI_AWCACHE),
        .saxigp2_awid({1'b0,1'b0,1'b0,1'b0,1'b0,1'b0}),
        .saxigp2_awlen(sc_data_M00_AXI_AWLEN),
        .saxigp2_awlock(sc_data_M00_AXI_AWLOCK),
        .saxigp2_awprot(sc_data_M00_AXI_AWPROT),
        .saxigp2_awqos(sc_data_M00_AXI_AWQOS),
        .saxigp2_awready(sc_data_M00_AXI_AWREADY),
        .saxigp2_awsize(sc_data_M00_AXI_AWSIZE),
        .saxigp2_awuser(1'b0),
        .saxigp2_awvalid(sc_data_M00_AXI_AWVALID),
        .saxigp2_bready(sc_data_M00_AXI_BREADY),
        .saxigp2_bresp(sc_data_M00_AXI_BRESP),
        .saxigp2_bvalid(sc_data_M00_AXI_BVALID),
        .saxigp2_rdata(sc_data_M00_AXI_RDATA),
        .saxigp2_rlast(sc_data_M00_AXI_RLAST),
        .saxigp2_rready(sc_data_M00_AXI_RREADY),
        .saxigp2_rresp(sc_data_M00_AXI_RRESP),
        .saxigp2_rvalid(sc_data_M00_AXI_RVALID),
        .saxigp2_wdata(sc_data_M00_AXI_WDATA),
        .saxigp2_wlast(sc_data_M00_AXI_WLAST),
        .saxigp2_wready(sc_data_M00_AXI_WREADY),
        .saxigp2_wstrb(sc_data_M00_AXI_WSTRB),
        .saxigp2_wvalid(sc_data_M00_AXI_WVALID),
        .saxihp0_fpd_aclk(ps_pl_clk1));
  system_rst_ctrl_0 rst_ctrl
       (.aux_reset_in(1'b1),
        .dcm_locked(1'b1),
        .ext_reset_in(ps_pl_resetn0),
        .interconnect_aresetn(rst_ctrl_interconnect_aresetn),
        .mb_debug_sys_rst(1'b0),
        .peripheral_aresetn(rst_ctrl_peripheral_aresetn),
        .slowest_sync_clk(ps_pl_clk0));
  system_rst_sensor_0 rst_sensor
       (.aux_reset_in(1'b1),
        .dcm_locked(clk_sensor_gen_locked),
        .ext_reset_in(ps_pl_resetn0),
        .mb_debug_sys_rst(1'b0),
        .peripheral_aresetn(rst_sensor_peripheral_aresetn),
        .slowest_sync_clk(clk_sensor_gen_clk_sensor));
  system_rst_sys_0 rst_sys
       (.aux_reset_in(1'b1),
        .dcm_locked(1'b1),
        .ext_reset_in(ps_pl_resetn0),
        .interconnect_aresetn(rst_sys_interconnect_aresetn),
        .mb_debug_sys_rst(1'b0),
        .peripheral_aresetn(rst_sys_peripheral_aresetn),
        .slowest_sync_clk(ps_pl_clk1));
  system_sc_ctrl_0 sc_ctrl
       (.M00_AXI_araddr(sc_ctrl_M00_AXI_ARADDR),
        .M00_AXI_arready(sc_ctrl_M00_AXI_ARREADY),
        .M00_AXI_arvalid(sc_ctrl_M00_AXI_ARVALID),
        .M00_AXI_awaddr(sc_ctrl_M00_AXI_AWADDR),
        .M00_AXI_awready(sc_ctrl_M00_AXI_AWREADY),
        .M00_AXI_awvalid(sc_ctrl_M00_AXI_AWVALID),
        .M00_AXI_bready(sc_ctrl_M00_AXI_BREADY),
        .M00_AXI_bresp(sc_ctrl_M00_AXI_BRESP),
        .M00_AXI_bvalid(sc_ctrl_M00_AXI_BVALID),
        .M00_AXI_rdata(sc_ctrl_M00_AXI_RDATA),
        .M00_AXI_rready(sc_ctrl_M00_AXI_RREADY),
        .M00_AXI_rresp(sc_ctrl_M00_AXI_RRESP),
        .M00_AXI_rvalid(sc_ctrl_M00_AXI_RVALID),
        .M00_AXI_wdata(sc_ctrl_M00_AXI_WDATA),
        .M00_AXI_wready(sc_ctrl_M00_AXI_WREADY),
        .M00_AXI_wvalid(sc_ctrl_M00_AXI_WVALID),
        .M01_AXI_araddr(sc_ctrl_M01_AXI_ARADDR),
        .M01_AXI_arprot(sc_ctrl_M01_AXI_ARPROT),
        .M01_AXI_arready(sc_ctrl_M01_AXI_ARREADY),
        .M01_AXI_arvalid(sc_ctrl_M01_AXI_ARVALID),
        .M01_AXI_awaddr(sc_ctrl_M01_AXI_AWADDR),
        .M01_AXI_awprot(sc_ctrl_M01_AXI_AWPROT),
        .M01_AXI_awready(sc_ctrl_M01_AXI_AWREADY),
        .M01_AXI_awvalid(sc_ctrl_M01_AXI_AWVALID),
        .M01_AXI_bready(sc_ctrl_M01_AXI_BREADY),
        .M01_AXI_bresp(sc_ctrl_M01_AXI_BRESP),
        .M01_AXI_bvalid(sc_ctrl_M01_AXI_BVALID),
        .M01_AXI_rdata(sc_ctrl_M01_AXI_RDATA),
        .M01_AXI_rready(sc_ctrl_M01_AXI_RREADY),
        .M01_AXI_rresp(sc_ctrl_M01_AXI_RRESP),
        .M01_AXI_rvalid(sc_ctrl_M01_AXI_RVALID),
        .M01_AXI_wdata(sc_ctrl_M01_AXI_WDATA),
        .M01_AXI_wready(sc_ctrl_M01_AXI_WREADY),
        .M01_AXI_wstrb(sc_ctrl_M01_AXI_WSTRB),
        .M01_AXI_wvalid(sc_ctrl_M01_AXI_WVALID),
        .M02_AXI_araddr(sc_ctrl_M02_AXI_ARADDR),
        .M02_AXI_arready(sc_ctrl_M02_AXI_ARREADY),
        .M02_AXI_arvalid(sc_ctrl_M02_AXI_ARVALID),
        .M02_AXI_awaddr(sc_ctrl_M02_AXI_AWADDR),
        .M02_AXI_awready(sc_ctrl_M02_AXI_AWREADY),
        .M02_AXI_awvalid(sc_ctrl_M02_AXI_AWVALID),
        .M02_AXI_bready(sc_ctrl_M02_AXI_BREADY),
        .M02_AXI_bresp(sc_ctrl_M02_AXI_BRESP),
        .M02_AXI_bvalid(sc_ctrl_M02_AXI_BVALID),
        .M02_AXI_rdata(sc_ctrl_M02_AXI_RDATA),
        .M02_AXI_rready(sc_ctrl_M02_AXI_RREADY),
        .M02_AXI_rresp(sc_ctrl_M02_AXI_RRESP),
        .M02_AXI_rvalid(sc_ctrl_M02_AXI_RVALID),
        .M02_AXI_wdata(sc_ctrl_M02_AXI_WDATA),
        .M02_AXI_wready(sc_ctrl_M02_AXI_WREADY),
        .M02_AXI_wvalid(sc_ctrl_M02_AXI_WVALID),
        .S00_AXI_araddr(ps_M_AXI_HPM0_FPD_ARADDR),
        .S00_AXI_arburst(ps_M_AXI_HPM0_FPD_ARBURST),
        .S00_AXI_arcache(ps_M_AXI_HPM0_FPD_ARCACHE),
        .S00_AXI_arid(ps_M_AXI_HPM0_FPD_ARID),
        .S00_AXI_arlen(ps_M_AXI_HPM0_FPD_ARLEN),
        .S00_AXI_arlock(ps_M_AXI_HPM0_FPD_ARLOCK),
        .S00_AXI_arprot(ps_M_AXI_HPM0_FPD_ARPROT),
        .S00_AXI_arqos(ps_M_AXI_HPM0_FPD_ARQOS),
        .S00_AXI_arready(ps_M_AXI_HPM0_FPD_ARREADY),
        .S00_AXI_arsize(ps_M_AXI_HPM0_FPD_ARSIZE),
        .S00_AXI_aruser(ps_M_AXI_HPM0_FPD_ARUSER),
        .S00_AXI_arvalid(ps_M_AXI_HPM0_FPD_ARVALID),
        .S00_AXI_awaddr(ps_M_AXI_HPM0_FPD_AWADDR),
        .S00_AXI_awburst(ps_M_AXI_HPM0_FPD_AWBURST),
        .S00_AXI_awcache(ps_M_AXI_HPM0_FPD_AWCACHE),
        .S00_AXI_awid(ps_M_AXI_HPM0_FPD_AWID),
        .S00_AXI_awlen(ps_M_AXI_HPM0_FPD_AWLEN),
        .S00_AXI_awlock(ps_M_AXI_HPM0_FPD_AWLOCK),
        .S00_AXI_awprot(ps_M_AXI_HPM0_FPD_AWPROT),
        .S00_AXI_awqos(ps_M_AXI_HPM0_FPD_AWQOS),
        .S00_AXI_awready(ps_M_AXI_HPM0_FPD_AWREADY),
        .S00_AXI_awsize(ps_M_AXI_HPM0_FPD_AWSIZE),
        .S00_AXI_awuser(ps_M_AXI_HPM0_FPD_AWUSER),
        .S00_AXI_awvalid(ps_M_AXI_HPM0_FPD_AWVALID),
        .S00_AXI_bid(ps_M_AXI_HPM0_FPD_BID),
        .S00_AXI_bready(ps_M_AXI_HPM0_FPD_BREADY),
        .S00_AXI_bresp(ps_M_AXI_HPM0_FPD_BRESP),
        .S00_AXI_bvalid(ps_M_AXI_HPM0_FPD_BVALID),
        .S00_AXI_rdata(ps_M_AXI_HPM0_FPD_RDATA),
        .S00_AXI_rid(ps_M_AXI_HPM0_FPD_RID),
        .S00_AXI_rlast(ps_M_AXI_HPM0_FPD_RLAST),
        .S00_AXI_rready(ps_M_AXI_HPM0_FPD_RREADY),
        .S00_AXI_rresp(ps_M_AXI_HPM0_FPD_RRESP),
        .S00_AXI_rvalid(ps_M_AXI_HPM0_FPD_RVALID),
        .S00_AXI_wdata(ps_M_AXI_HPM0_FPD_WDATA),
        .S00_AXI_wlast(ps_M_AXI_HPM0_FPD_WLAST),
        .S00_AXI_wready(ps_M_AXI_HPM0_FPD_WREADY),
        .S00_AXI_wstrb(ps_M_AXI_HPM0_FPD_WSTRB),
        .S00_AXI_wvalid(ps_M_AXI_HPM0_FPD_WVALID),
        .aclk(ps_pl_clk0),
        .aresetn(rst_ctrl_interconnect_aresetn));
  system_sc_data_0 sc_data
       (.M00_AXI_araddr(sc_data_M00_AXI_ARADDR),
        .M00_AXI_arburst(sc_data_M00_AXI_ARBURST),
        .M00_AXI_arcache(sc_data_M00_AXI_ARCACHE),
        .M00_AXI_arlen(sc_data_M00_AXI_ARLEN),
        .M00_AXI_arlock(sc_data_M00_AXI_ARLOCK),
        .M00_AXI_arprot(sc_data_M00_AXI_ARPROT),
        .M00_AXI_arqos(sc_data_M00_AXI_ARQOS),
        .M00_AXI_arready(sc_data_M00_AXI_ARREADY),
        .M00_AXI_arsize(sc_data_M00_AXI_ARSIZE),
        .M00_AXI_arvalid(sc_data_M00_AXI_ARVALID),
        .M00_AXI_awaddr(sc_data_M00_AXI_AWADDR),
        .M00_AXI_awburst(sc_data_M00_AXI_AWBURST),
        .M00_AXI_awcache(sc_data_M00_AXI_AWCACHE),
        .M00_AXI_awlen(sc_data_M00_AXI_AWLEN),
        .M00_AXI_awlock(sc_data_M00_AXI_AWLOCK),
        .M00_AXI_awprot(sc_data_M00_AXI_AWPROT),
        .M00_AXI_awqos(sc_data_M00_AXI_AWQOS),
        .M00_AXI_awready(sc_data_M00_AXI_AWREADY),
        .M00_AXI_awsize(sc_data_M00_AXI_AWSIZE),
        .M00_AXI_awvalid(sc_data_M00_AXI_AWVALID),
        .M00_AXI_bready(sc_data_M00_AXI_BREADY),
        .M00_AXI_bresp(sc_data_M00_AXI_BRESP),
        .M00_AXI_bvalid(sc_data_M00_AXI_BVALID),
        .M00_AXI_rdata(sc_data_M00_AXI_RDATA),
        .M00_AXI_rlast(sc_data_M00_AXI_RLAST),
        .M00_AXI_rready(sc_data_M00_AXI_RREADY),
        .M00_AXI_rresp(sc_data_M00_AXI_RRESP),
        .M00_AXI_rvalid(sc_data_M00_AXI_RVALID),
        .M00_AXI_wdata(sc_data_M00_AXI_WDATA),
        .M00_AXI_wlast(sc_data_M00_AXI_WLAST),
        .M00_AXI_wready(sc_data_M00_AXI_WREADY),
        .M00_AXI_wstrb(sc_data_M00_AXI_WSTRB),
        .M00_AXI_wvalid(sc_data_M00_AXI_WVALID),
        .S00_AXI_araddr(dma_M_AXI_MM2S_ARADDR),
        .S00_AXI_arburst(dma_M_AXI_MM2S_ARBURST),
        .S00_AXI_arcache(dma_M_AXI_MM2S_ARCACHE),
        .S00_AXI_arlen(dma_M_AXI_MM2S_ARLEN),
        .S00_AXI_arlock(1'b0),
        .S00_AXI_arprot(dma_M_AXI_MM2S_ARPROT),
        .S00_AXI_arqos({1'b0,1'b0,1'b0,1'b0}),
        .S00_AXI_arready(dma_M_AXI_MM2S_ARREADY),
        .S00_AXI_arsize(dma_M_AXI_MM2S_ARSIZE),
        .S00_AXI_arvalid(dma_M_AXI_MM2S_ARVALID),
        .S00_AXI_rdata(dma_M_AXI_MM2S_RDATA),
        .S00_AXI_rlast(dma_M_AXI_MM2S_RLAST),
        .S00_AXI_rready(dma_M_AXI_MM2S_RREADY),
        .S00_AXI_rresp(dma_M_AXI_MM2S_RRESP),
        .S00_AXI_rvalid(dma_M_AXI_MM2S_RVALID),
        .S01_AXI_awaddr(dma_M_AXI_S2MM_AWADDR),
        .S01_AXI_awburst(dma_M_AXI_S2MM_AWBURST),
        .S01_AXI_awcache(dma_M_AXI_S2MM_AWCACHE),
        .S01_AXI_awlen(dma_M_AXI_S2MM_AWLEN),
        .S01_AXI_awlock(1'b0),
        .S01_AXI_awprot(dma_M_AXI_S2MM_AWPROT),
        .S01_AXI_awqos({1'b0,1'b0,1'b0,1'b0}),
        .S01_AXI_awready(dma_M_AXI_S2MM_AWREADY),
        .S01_AXI_awsize(dma_M_AXI_S2MM_AWSIZE),
        .S01_AXI_awvalid(dma_M_AXI_S2MM_AWVALID),
        .S01_AXI_bready(dma_M_AXI_S2MM_BREADY),
        .S01_AXI_bresp(dma_M_AXI_S2MM_BRESP),
        .S01_AXI_bvalid(dma_M_AXI_S2MM_BVALID),
        .S01_AXI_wdata(dma_M_AXI_S2MM_WDATA),
        .S01_AXI_wlast(dma_M_AXI_S2MM_WLAST),
        .S01_AXI_wready(dma_M_AXI_S2MM_WREADY),
        .S01_AXI_wstrb(dma_M_AXI_S2MM_WSTRB),
        .S01_AXI_wvalid(dma_M_AXI_S2MM_WVALID),
        .S02_AXI_awaddr(dma_gr_M_AXI_S2MM_AWADDR),
        .S02_AXI_awburst(dma_gr_M_AXI_S2MM_AWBURST),
        .S02_AXI_awcache(dma_gr_M_AXI_S2MM_AWCACHE),
        .S02_AXI_awlen(dma_gr_M_AXI_S2MM_AWLEN),
        .S02_AXI_awlock(1'b0),
        .S02_AXI_awprot(dma_gr_M_AXI_S2MM_AWPROT),
        .S02_AXI_awqos({1'b0,1'b0,1'b0,1'b0}),
        .S02_AXI_awready(dma_gr_M_AXI_S2MM_AWREADY),
        .S02_AXI_awsize(dma_gr_M_AXI_S2MM_AWSIZE),
        .S02_AXI_awvalid(dma_gr_M_AXI_S2MM_AWVALID),
        .S02_AXI_bready(dma_gr_M_AXI_S2MM_BREADY),
        .S02_AXI_bresp(dma_gr_M_AXI_S2MM_BRESP),
        .S02_AXI_bvalid(dma_gr_M_AXI_S2MM_BVALID),
        .S02_AXI_wdata(dma_gr_M_AXI_S2MM_WDATA),
        .S02_AXI_wlast(dma_gr_M_AXI_S2MM_WLAST),
        .S02_AXI_wready(dma_gr_M_AXI_S2MM_WREADY),
        .S02_AXI_wstrb(dma_gr_M_AXI_S2MM_WSTRB),
        .S02_AXI_wvalid(dma_gr_M_AXI_S2MM_WVALID),
        .aclk(ps_pl_clk1),
        .aresetn(rst_sys_interconnect_aresetn));
endmodule
