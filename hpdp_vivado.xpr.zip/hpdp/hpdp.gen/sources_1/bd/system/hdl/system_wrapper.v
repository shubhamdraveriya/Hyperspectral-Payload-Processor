//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Sun Oct 18 00:11:36 2026
//Host        : DESKTOP-KTJ622C running 64-bit major release  (build 9200)
//Command     : generate_target system_wrapper.bd
//Design      : system_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module system_wrapper
   (clk_link,
    clk_sem,
    gt_cplllock,
    gt_loopback,
    gt_powergood,
    gt_prbs_cnt_reset,
    gt_prbs_force_err,
    gt_prbs_sel,
    gt_reset_all,
    gt_reset_rx,
    gt_rx_done,
    gt_rxbufreset,
    gt_rxbufstatus,
    gt_rxbyteisaligned,
    gt_rxcharisk,
    gt_rxclkcorcnt,
    gt_rxdata,
    gt_rxdisperr,
    gt_rxnotintable,
    gt_rxpolarity,
    gt_rxprbserr,
    gt_rxprbslocked,
    gt_tx_done,
    gt_txcharisk,
    gt_txdata,
    gt_txpolarity,
    sem_cmd_busy,
    sem_cmd_code,
    sem_cmd_strobe,
    sem_grant,
    sem_icap_avail,
    sem_mon_data,
    sem_mon_write,
    sem_status,
    sfp_tx_enable);
  input clk_link;
  input clk_sem;
  input [1:0]gt_cplllock;
  output [2:0]gt_loopback;
  input [1:0]gt_powergood;
  output gt_prbs_cnt_reset;
  output gt_prbs_force_err;
  output [3:0]gt_prbs_sel;
  output gt_reset_all;
  output gt_reset_rx;
  input gt_rx_done;
  output [1:0]gt_rxbufreset;
  input [5:0]gt_rxbufstatus;
  input [1:0]gt_rxbyteisaligned;
  input [3:0]gt_rxcharisk;
  input [3:0]gt_rxclkcorcnt;
  input [31:0]gt_rxdata;
  input [3:0]gt_rxdisperr;
  input [3:0]gt_rxnotintable;
  output gt_rxpolarity;
  input [1:0]gt_rxprbserr;
  input [1:0]gt_rxprbslocked;
  input gt_tx_done;
  output [1:0]gt_txcharisk;
  output [15:0]gt_txdata;
  output gt_txpolarity;
  input sem_cmd_busy;
  output [43:0]sem_cmd_code;
  output sem_cmd_strobe;
  output sem_grant;
  input sem_icap_avail;
  input [7:0]sem_mon_data;
  input sem_mon_write;
  input [9:0]sem_status;
  output [1:0]sfp_tx_enable;

  wire clk_link;
  wire clk_sem;
  wire [1:0]gt_cplllock;
  wire [2:0]gt_loopback;
  wire [1:0]gt_powergood;
  wire gt_prbs_cnt_reset;
  wire gt_prbs_force_err;
  wire [3:0]gt_prbs_sel;
  wire gt_reset_all;
  wire gt_reset_rx;
  wire gt_rx_done;
  wire [1:0]gt_rxbufreset;
  wire [5:0]gt_rxbufstatus;
  wire [1:0]gt_rxbyteisaligned;
  wire [3:0]gt_rxcharisk;
  wire [3:0]gt_rxclkcorcnt;
  wire [31:0]gt_rxdata;
  wire [3:0]gt_rxdisperr;
  wire [3:0]gt_rxnotintable;
  wire gt_rxpolarity;
  wire [1:0]gt_rxprbserr;
  wire [1:0]gt_rxprbslocked;
  wire gt_tx_done;
  wire [1:0]gt_txcharisk;
  wire [15:0]gt_txdata;
  wire gt_txpolarity;
  wire sem_cmd_busy;
  wire [43:0]sem_cmd_code;
  wire sem_cmd_strobe;
  wire sem_grant;
  wire sem_icap_avail;
  wire [7:0]sem_mon_data;
  wire sem_mon_write;
  wire [9:0]sem_status;
  wire [1:0]sfp_tx_enable;

  system system_i
       (.clk_link(clk_link),
        .clk_sem(clk_sem),
        .gt_cplllock(gt_cplllock),
        .gt_loopback(gt_loopback),
        .gt_powergood(gt_powergood),
        .gt_prbs_cnt_reset(gt_prbs_cnt_reset),
        .gt_prbs_force_err(gt_prbs_force_err),
        .gt_prbs_sel(gt_prbs_sel),
        .gt_reset_all(gt_reset_all),
        .gt_reset_rx(gt_reset_rx),
        .gt_rx_done(gt_rx_done),
        .gt_rxbufreset(gt_rxbufreset),
        .gt_rxbufstatus(gt_rxbufstatus),
        .gt_rxbyteisaligned(gt_rxbyteisaligned),
        .gt_rxcharisk(gt_rxcharisk),
        .gt_rxclkcorcnt(gt_rxclkcorcnt),
        .gt_rxdata(gt_rxdata),
        .gt_rxdisperr(gt_rxdisperr),
        .gt_rxnotintable(gt_rxnotintable),
        .gt_rxpolarity(gt_rxpolarity),
        .gt_rxprbserr(gt_rxprbserr),
        .gt_rxprbslocked(gt_rxprbslocked),
        .gt_tx_done(gt_tx_done),
        .gt_txcharisk(gt_txcharisk),
        .gt_txdata(gt_txdata),
        .gt_txpolarity(gt_txpolarity),
        .sem_cmd_busy(sem_cmd_busy),
        .sem_cmd_code(sem_cmd_code),
        .sem_cmd_strobe(sem_cmd_strobe),
        .sem_grant(sem_grant),
        .sem_icap_avail(sem_icap_avail),
        .sem_mon_data(sem_mon_data),
        .sem_mon_write(sem_mon_write),
        .sem_status(sem_status),
        .sfp_tx_enable(sfp_tx_enable));
endmodule
