`timescale 1ns / 1ps

// Corner turn (SPEC.md 6.3): reorders each line from BIL (band-major) to BIP
// (pixel-major) through two line buffers (ping-pong).
//
// Write side: never stalls. A line is written to the free buffer, sample i of
// the BIL line at address i = z*Nx + x. If no buffer is free when a line
// starts, the line is dropped (CT-04).
// Read side: AXI4-Stream, may be back-pressured. Reads x outer, z inner, i.e.
// address z*Nx + x, as each completed line's turn comes.
//
// Every line, written or dropped, queues a descriptor in arrival order. A
// dropped line is sent as a fill line of zeros, so scenes keep their geometry
// and the compressor stays aligned with scene boundaries; the drop is counted
// (SYS-05). If the descriptor queue is full too, the line is lost without fill
// (counted separately; the scene guard after the corner turn pads the scene).
// A lost line that started a scene passes its first-of-scene marker on to the
// next line sent, so no scene start is lost unless a whole scene is.
//
// Every line carries, through its descriptor, its scene's timestamp (the number
// of lines that came in before the scene's first line, as the sensor emulator's
// scene timestamp) and an uncorrectable-memory-error mark (RAD-06): set if any
// sample of the line came with s_ue (calibration table), or per sample if its
// buffer word read back uncorrectable. A whole scene lost thus takes its
// timestamp with it, and errors stay with the scene they hit.
//
// Output: tuser[0] first sample of a scene, tuser[1] first sample of a line,
// tlast last sample of a line; m_axis_scene_ts, m_axis_ue and m_axis_fill (a
// sample of a fill line) with every sample.
// cfg must be static while lines flow.
module corner_turn import frontend_pkg::*, ecc_pkg::*; #(
    parameter int NX_MAX = 512,
    parameter int NZ_MAX = 256
) (
    input  logic        clk,
    input  logic        rst,
    input  fe_cfg_t     cfg,

    input  logic        s_valid,
    input  logic [15:0] s_data,
    input  logic [1:0]  s_user,         // [0] first sample of a scene, [1] first of a line
    input  logic        s_last,
    input  logic        s_ue,           // uncorrectable table error on this sample

    output logic [15:0] m_axis_tdata,
    output logic [1:0]  m_axis_tuser,
    output logic [23:0] m_axis_scene_ts,
    output logic        m_axis_ue,
    output logic        m_axis_fill,
    output logic        m_axis_tlast,
    output logic        m_axis_tvalid,
    input  logic        m_axis_tready,

    input  logic        cnt_clr,
    output logic [31:0] lines_out,      // counters saturate; cnt_clr clears them
    output logic [31:0] dropped_lines,  // includes unfilled_lines
    output logic [31:0] unfilled_lines,

    input  ecc_inj_t    inj,            // buffer ECC (SPEC RAD-02)
    output ecc_evt_t    ecc,
    output logic        tmr_mismatch    // the voted state copies disagree (RAD-04): control
                                        // state, write and read addresses
);
    localparam int EB = $clog2(NX_MAX * NZ_MAX);
    localparam int DQ = 16;             // line descriptors
    localparam int OQ = 16;             // output FIFO
    localparam int RL = 4;              // buffer read latency (UltraRAM cascade pipelining)

    typedef struct packed {
        logic        fill;              // dropped line: send zeros
        logic        buffer;
        logic        scene;             // first line of a scene
        logic        ue;                // uncorrectable table error in the line
        logic [23:0] ts;                // the line's scene timestamp
    } desc_t;

    // buffers holding a line not yet read out: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic [2-1:0] full_0, full_1, full_2;
    logic [2-1:0] full;
    assign full = (full_0 & full_1) | (full_0 & full_2) | (full_1 & full_2);

    // ---------------------------------------------------------------------
    // Write side
    // ---------------------------------------------------------------------
    // buffer the next line goes to: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic wb_0, wb_1, wb_2;
    logic wb;
    assign wb = (wb_0 & wb_1) | (wb_0 & wb_2) | (wb_1 & wb_2);
    // writing the line: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic wr_on_0, wr_on_1, wr_on_2;
    logic wr_on;
    assign wr_on = (wr_on_0 & wr_on_1) | (wr_on_0 & wr_on_2) | (wr_on_1 & wr_on_2);
    // dropping the line: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic wr_drop_0, wr_drop_1, wr_drop_2;
    logic wr_drop;
    assign wr_drop = (wr_drop_0 & wr_drop_1) | (wr_drop_0 & wr_drop_2) | (wr_drop_1 & wr_drop_2);
    // the line starts a scene: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic wr_scene_0, wr_scene_1, wr_scene_2;
    logic wr_scene;
    assign wr_scene = (wr_scene_0 & wr_scene_1) | (wr_scene_0 & wr_scene_2) | (wr_scene_1 & wr_scene_2);
    // a lost line started a scene: mark the next one sent: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic scene_lost_0, scene_lost_1, scene_lost_2;
    logic scene_lost;
    assign scene_lost = (scene_lost_0 & scene_lost_1) | (scene_lost_0 & scene_lost_2) | (scene_lost_1 & scene_lost_2);
    // write index in the line: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic [EB-1:0] wcnt_0, wcnt_1, wcnt_2;
    logic [EB-1:0] wcnt;
    assign wcnt = (wcnt_0 & wcnt_1) | (wcnt_0 & wcnt_2) | (wcnt_1 & wcnt_2);
    // lines come in: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic [24-1:0] lines_in_0, lines_in_1, lines_in_2;
    logic [24-1:0] lines_in;
    assign lines_in = (lines_in_0 & lines_in_1) | (lines_in_0 & lines_in_2) | (lines_in_1 & lines_in_2);
    // timestamp of the current scene: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic [24-1:0] cur_ts_0, cur_ts_1, cur_ts_2;
    logic [24-1:0] cur_ts;
    assign cur_ts = (cur_ts_0 & cur_ts_1) | (cur_ts_0 & cur_ts_2) | (cur_ts_1 & cur_ts_2);
    // table error seen in the line so far: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic line_ue_0, line_ue_1, line_ue_2;
    logic line_ue;
    assign line_ue = (line_ue_0 & line_ue_1) | (line_ue_0 & line_ue_2) | (line_ue_1 & line_ue_2);

    wire           line_start = s_valid && s_user[1];
    wire           wr_now     = s_valid && (line_start ? !full[wb] : wr_on);
    wire           drop_now   = s_valid && (line_start ?  full[wb] : wr_drop);
    wire [EB-1:0]  widx       = line_start ? '0 : wcnt;
    wire           scene_now  = line_start ? s_user[0] : wr_scene;
    wire [23:0]    ts_now     = (line_start && s_user[0]) ? lines_in : cur_ts;
    wire           ue_now     = s_ue || (!line_start && line_ue);

    logic  dq_push, dq_pop, dq_empty;
    desc_t dq_din, dq_dout;
    logic [$clog2(DQ):0] dq_count;

    always_comb begin
        dq_push = 1'b0;
        dq_din  = '{fill: 1'b0, buffer: wb, scene: scene_now || scene_lost, ue: ue_now, ts: ts_now};
        if (wr_now && s_last) begin
            dq_push = 1'b1;
        end else if (drop_now && s_last && dq_count <= DQ - 3) begin
            // keep room for the two buffers' descriptors
            dq_push     = 1'b1;
            dq_din.fill = 1'b1;
            dq_din.ue   = 1'b0;             // zeros, not the corrupted data
        end
    end

    always_ff @(posedge clk) begin
        {wcnt_0, wcnt_1, wcnt_2} <= {3{wcnt}};   // refresh (RAD-04)
        {wr_on_0, wr_on_1, wr_on_2} <= {3{wr_on}};   // refresh (RAD-04)
        {wr_drop_0, wr_drop_1, wr_drop_2} <= {3{wr_drop}};   // refresh (RAD-04)
        {wr_scene_0, wr_scene_1, wr_scene_2} <= {3{wr_scene}};   // refresh (RAD-04)
        {scene_lost_0, scene_lost_1, scene_lost_2} <= {3{scene_lost}};   // refresh (RAD-04)
        {line_ue_0, line_ue_1, line_ue_2} <= {3{line_ue}};   // refresh (RAD-04)
        {lines_in_0, lines_in_1, lines_in_2} <= {3{lines_in}};   // refresh (RAD-04)
        {cur_ts_0, cur_ts_1, cur_ts_2} <= {3{cur_ts}};   // refresh (RAD-04)
        {wb_0, wb_1, wb_2} <= {3{wb}};   // refresh (RAD-04)
        if (rst) begin
            {wb_0, wb_1, wb_2} <= {3{1'b0}};
            {wr_on_0, wr_on_1, wr_on_2} <= {3{1'b0}};
            {wr_drop_0, wr_drop_1, wr_drop_2} <= {3{1'b0}};
            {wr_scene_0, wr_scene_1, wr_scene_2} <= {3{1'b0}};
            {scene_lost_0, scene_lost_1, scene_lost_2} <= {3{1'b0}};
            {line_ue_0, line_ue_1, line_ue_2} <= {3{1'b0}};
            {wcnt_0, wcnt_1, wcnt_2} <= {3{EB'(0)}};
            {lines_in_0, lines_in_1, lines_in_2} <= {3{24'd0}};
            {cur_ts_0, cur_ts_1, cur_ts_2} <= {3{24'd0}};
            dropped_lines  <= '0;
            unfilled_lines <= '0;
        end else if (s_valid) begin
            {wcnt_0, wcnt_1, wcnt_2} <= {3{widx + 1'b1}};
            {line_ue_0, line_ue_1, line_ue_2} <= {3{ue_now}};
            if (line_start) begin
                {wr_on_0, wr_on_1, wr_on_2} <= {3{!full[wb]}};
                {wr_drop_0, wr_drop_1, wr_drop_2} <= {3{full[wb]}};
                {wr_scene_0, wr_scene_1, wr_scene_2} <= {3{s_user[0]}};
                {lines_in_0, lines_in_1, lines_in_2} <= {3{lines_in + 24'd1}};
                {cur_ts_0, cur_ts_1, cur_ts_2} <= {3{ts_now}};
            end
            if (s_last) begin
                {wr_on_0, wr_on_1, wr_on_2} <= {3{1'b0}};
                {wr_drop_0, wr_drop_1, wr_drop_2} <= {3{1'b0}};
                {scene_lost_0, scene_lost_1, scene_lost_2} <= {3{dq_push ? 1'b0 : (scene_lost || (drop_now && scene_now))}};
                if (wr_now) {wb_0, wb_1, wb_2} <= {3{!wb}};
                if (drop_now) begin
                    dropped_lines <= sat_inc(dropped_lines);
                    if (!dq_push) unfilled_lines <= sat_inc(unfilled_lines);
                end
            end
        end
        if (!rst && cnt_clr) begin
            dropped_lines  <= '0;
            unfilled_lines <= '0;
        end
    end

    sync_fifo #(.WIDTH($bits(desc_t)), .DEPTH(DQ)) u_desc (
        .clk   (clk),
        .rst   (rst),
        .din   (dq_din),
        .wr_en (dq_push),
        .rd_en (dq_pop),
        .dout  (dq_dout),
        .empty (dq_empty),
        .full  (),
        .count (dq_count)
    );

    // ---------------------------------------------------------------------
    // Read side
    // ---------------------------------------------------------------------
    // reading a line: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic rd_on_0, rd_on_1, rd_on_2;
    logic rd_on;
    assign rd_on = (rd_on_0 & rd_on_1) | (rd_on_0 & rd_on_2) | (rd_on_1 & rd_on_2);
    // descriptor of the line being read: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic [$bits(desc_t)-1:0] rd_0, rd_1, rd_2;
    desc_t rd;
    assign rd = desc_t'((rd_0 & rd_1) | (rd_0 & rd_2) | (rd_1 & rd_2));
    // read pixel: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic [16-1:0] xr_0, xr_1, xr_2;
    logic [16-1:0] xr;
    assign xr = (xr_0 & xr_1) | (xr_0 & xr_2) | (xr_1 & xr_2);
    // read band: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic [16-1:0] zr_0, zr_1, zr_2;
    logic [16-1:0] zr;
    assign zr = (zr_0 & zr_1) | (zr_0 & zr_2) | (zr_1 & zr_2);
    // read address in the buffer: three voted copies, kept apart through synthesis (RAD-04)
    (* DONT_TOUCH = "true" *) logic [EB-1:0] ra_0, ra_1, ra_2;
    logic [EB-1:0] ra;
    assign ra = (ra_0 & ra_1) | (ra_0 & ra_2) | (ra_1 & ra_2);
    logic [$clog2(OQ):0] oq_count;
    logic [$clog2(RL):0] inflight;      // reads issued, not yet in the output FIFO

    wire last_zr = (zr == cfg.nz - 16'd1);
    wire last_xr = (xr == cfg.nx - 16'd1);
    wire rd_end  = last_zr && last_xr;
    wire credit  = (oq_count + inflight) < OQ;
    wire issue   = rd_on && credit;
    assign dq_pop = !dq_empty && (!rd_on || (issue && rd_end));

    // full[]: set by the writer at the end of a line, cleared by the reader
    // after the line's last read (never the same buffer in the same cycle)
    always_ff @(posedge clk) begin
        {full_0, full_1, full_2} <= {3{full}};   // refresh (RAD-04)
        if (rst) begin
            {full_0, full_1, full_2} <= {3{2'b00}};
        end else begin
            if (wr_now && s_last)               {full_0[wb], full_1[wb], full_2[wb]} <= {3{1'b1}};
            if (issue && rd_end && !rd.fill)    {full_0[rd.buffer], full_1[rd.buffer], full_2[rd.buffer]} <= {3{1'b0}};
        end
    end

    always_ff @(posedge clk) begin
        {rd_0, rd_1, rd_2} <= {3{rd}};   // refresh (RAD-04)
        {xr_0, xr_1, xr_2} <= {3{xr}};   // refresh (RAD-04)
        {zr_0, zr_1, zr_2} <= {3{zr}};   // refresh (RAD-04)
        {ra_0, ra_1, ra_2} <= {3{ra}};   // refresh (RAD-04)
        {rd_on_0, rd_on_1, rd_on_2} <= {3{rd_on}};   // refresh (RAD-04)
        if (rst) begin
            {rd_on_0, rd_on_1, rd_on_2} <= {3{1'b0}};
            {rd_0, rd_1, rd_2} <= {3{desc_t'(0)}};
            {xr_0, xr_1, xr_2} <= {3{16'd0}};
            {zr_0, zr_1, zr_2} <= {3{16'd0}};
            {ra_0, ra_1, ra_2} <= {3{EB'(0)}};
            lines_out <= '0;
        end else begin
            if (issue) begin
                if (!last_zr) begin
                    {zr_0, zr_1, zr_2} <= {3{zr + 16'd1}};
                    {ra_0, ra_1, ra_2} <= {3{ra + EB'(cfg.nx)}};
                end else begin
                    {zr_0, zr_1, zr_2} <= {3{16'd0}};
                    {xr_0, xr_1, xr_2} <= {3{xr + 16'd1}};
                    {ra_0, ra_1, ra_2} <= {3{EB'(xr + 16'd1)}};
                end
                if (rd_end) begin
                    {rd_on_0, rd_on_1, rd_on_2} <= {3{1'b0}};
                    lines_out <= sat_inc(lines_out);
                end
            end
            if (cnt_clr) lines_out <= '0;
            if (dq_pop) begin
                {rd_on_0, rd_on_1, rd_on_2} <= {3{1'b1}};
                {rd_0, rd_1, rd_2} <= {3{dq_dout}};
                {xr_0, xr_1, xr_2} <= {3{16'd0}};
                {zr_0, zr_1, zr_2} <= {3{16'd0}};
                {ra_0, ra_1, ra_2} <= {3{EB'(0)}};
            end
        end
    end

    // ---------------------------------------------------------------------
    // Buffers and read pipeline (RL cycles)
    // ---------------------------------------------------------------------
    logic [15:0] rdata;

    sample_ram #(
        .DEPTH   (2 * NX_MAX * NZ_MAX),
        .STYLE   (NX_MAX * NZ_MAX >= 32768 ? "ultra" : "block"),
        .LATENCY (RL)
    ) u_buf (
        .clk   (clk),
        .rst   (rst),
        .ce    (1'b1),
        .we    (wr_now),
        .wlast (s_last),
        .waddr ({wb, widx}),
        .wdata (s_data),
        .re    (issue && !rd.fill),
        .raddr ({rd.buffer, ra}),
        .rdata (rdata),
        .inj   (inj),
        .ecc   (ecc)
    );

    typedef struct packed {
        logic        fill;
        logic [1:0]  user;
        logic        last;
        logic        ue;
        logic [23:0] ts;
    } rtag_t;

    logic  vp [RL];
    rtag_t gp [RL];
    wire   first = (xr == 16'd0) && (zr == 16'd0);
    wire   v_out = vp[RL - 1];
    rtag_t g_out;
    assign g_out = gp[RL - 1];

    always_ff @(posedge clk) begin
        if (rst) begin
            for (int i = 0; i < RL; i++) vp[i] <= 1'b0;
            inflight <= '0;
        end else begin
            vp[0] <= issue;
            for (int i = 1; i < RL; i++) vp[i] <= vp[i - 1];
            inflight <= inflight + issue - v_out;
        end
        gp[0] <= '{fill: rd.fill, user: {first, first && rd.scene}, last: rd_end, ue: rd.ue, ts: rd.ts};
        for (int i = 1; i < RL; i++) gp[i] <= gp[i - 1];
    end

    // Output FIFO (credit-based: never written when full) and register slice;
    // a sample is marked uncorrectable by its line (table) or its own word (buffer)
    logic        oq_empty, oq_rd, sk_ready;
    logic [44:0] oq_dout;
    wire         ue_out = !g_out.fill && (g_out.ue || ecc.dbe);

    sync_fifo #(.WIDTH(45), .DEPTH(OQ)) u_out (
        .clk   (clk),
        .rst   (rst),
        .din   ({g_out.ts, g_out.fill, ue_out, g_out.last, g_out.user, g_out.fill ? 16'd0 : rdata}),
        .wr_en (v_out),
        .rd_en (oq_rd),
        .dout  (oq_dout),
        .empty (oq_empty),
        .full  (),
        .count (oq_count)
    );

    assign oq_rd = !oq_empty && sk_ready;

    axis_skid_buffer #(.DATA_W(16), .USER_W(28)) u_skid (
        .clk      (clk),
        .rst      (rst),
        .s_tdata  (oq_dout[15:0]),
        .s_tuser  ({oq_dout[44:19], oq_dout[17:16]}),
        .s_tlast  (oq_dout[18]),
        .s_tvalid (!oq_empty),
        .s_tready (sk_ready),
        .m_tdata  (m_axis_tdata),
        .m_tuser  ({m_axis_scene_ts, m_axis_fill, m_axis_ue, m_axis_tuser}),
        .m_tlast  (m_axis_tlast),
        .m_tvalid (m_axis_tvalid),
        .m_tready (m_axis_tready)
    );

    assign tmr_mismatch = (wcnt_0 != wcnt_1) || (wcnt_0 != wcnt_2) ||
                          (wr_on_0 != wr_on_1) || (wr_on_0 != wr_on_2) ||
                          (wr_drop_0 != wr_drop_1) || (wr_drop_0 != wr_drop_2) ||
                          (wr_scene_0 != wr_scene_1) || (wr_scene_0 != wr_scene_2) ||
                          (scene_lost_0 != scene_lost_1) || (scene_lost_0 != scene_lost_2) ||
                          (line_ue_0 != line_ue_1) || (line_ue_0 != line_ue_2) ||
                          (lines_in_0 != lines_in_1) || (lines_in_0 != lines_in_2) ||
                          (cur_ts_0 != cur_ts_1) || (cur_ts_0 != cur_ts_2) ||
                          (rd_0 != rd_1) || (rd_0 != rd_2) ||
                          (xr_0 != xr_1) || (xr_0 != xr_2) ||
                          (zr_0 != zr_1) || (zr_0 != zr_2) ||
                          (ra_0 != ra_1) || (ra_0 != ra_2) ||
                          (wb_0 != wb_1) || (wb_0 != wb_2) || (full_0 != full_1) || (full_0 != full_2) || (rd_on_0 != rd_on_1) || (rd_on_0 != rd_on_2);
endmodule
