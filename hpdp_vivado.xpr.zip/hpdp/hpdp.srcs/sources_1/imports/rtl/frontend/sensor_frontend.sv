`timescale 1ns / 1ps

// Sensor front end (SPEC.md 6.1 - 6.3):
//
//   DMA (128-bit raw BIL samples) -> sensor_emulator -> radiometric_corr
//     -> corner_turn -> m_axis (16-bit BIP samples, to the compressor)
//
// Only the corner turn output can be back-pressured; everything before it runs
// at the sensor's pace, and overflows are counted (SYS-05). The configuration
// comes in once per clock domain (the same values, synchronized by the caller).
module sensor_frontend import frontend_pkg::*, ecc_pkg::*; #(
    parameter int NX_MAX = 512,
    parameter int NZ_MAX = 256,
    parameter bit TABLE_PAIRS = (NX_MAX * NZ_MAX > 131072)   // calibration table layout (radiometric_corr)
) (
    input  logic         clk_sys,
    input  logic         rst_sys,
    input  fe_cfg_t      cfg_sys,
    input  logic         cnt_clr_sys,       // clear the clk_sys counters
    input  logic         clk_sensor,
    input  logic         rst_sensor,
    input  fe_cfg_t      cfg_sensor,
    input  logic         cnt_clr_sensor,    // clear the clk_sensor counters

    input  logic [127:0] s_dma_tdata,       // raw samples, 8 per beat, sample 0 in [15:0]
    input  logic         s_dma_tvalid,
    output logic         s_dma_tready,

    input  logic [127:0] s_tbl_tdata,       // calibration records, 2 per beat
    input  logic         s_tbl_tlast,
    input  logic         s_tbl_tvalid,
    output logic         s_tbl_tready,

    input  tbl_cmd_t     tbl_cmd,           // calibration table debug access (clk_sys)
    output logic [32:0]  tbl_rdata,
    output logic         tbl_done,

    input  ecc_inj_t     tbl_inj,           // memory ECC (SPEC RAD-02, clk_sys):
    output ecc_evt_t     tbl_ecc,           //   calibration table
    input  ecc_inj_t     ct_inj,            //   corner-turn buffers
    output ecc_evt_t     ct_ecc,
    output logic         ct_tmr_mismatch,   // corner turn: voted control state copies disagree (RAD-04)

    output logic [15:0]  m_axis_tdata,
    output logic [1:0]   m_axis_tuser,      // [0] first sample of a scene, [1] first of a line
    output logic [23:0]  m_axis_scene_ts,   // the sample's scene timestamp: lines before the
                                            // scene's first line, as the emulator's (SE-05)
    output logic         m_axis_ue,         // uncorrectable memory error in the sample (RAD-06)
    output logic         m_axis_fill,       // a sample of a fill line (a dropped line)
    output logic         m_axis_tlast,      // last sample of a line
    output logic         m_axis_tvalid,
    input  logic         m_axis_tready,

    output se_status_t   se_status,         // clk_sensor domain
    output fe_status_t   fe_status          // clk_sys domain
);
    logic        se_valid, se_last, rc_valid, rc_last, rc_ue;
    logic [15:0] se_data, rc_data;
    logic [1:0]  se_user, rc_user;

    sensor_emulator u_se (
        .clk_sys, .rst_sys,
        .s_axis_tdata  (s_dma_tdata),
        .s_axis_tvalid (s_dma_tvalid),
        .s_axis_tready (s_dma_tready),
        .m_valid       (se_valid),
        .m_data        (se_data),
        .m_user        (se_user),
        .m_last        (se_last),
        .clk_sensor, .rst_sensor,
        .cfg           (cfg_sensor),
        .cnt_clr       (cnt_clr_sensor),
        .status        (se_status)
    );

    radiometric_corr #(.NX_MAX(NX_MAX), .NZ_MAX(NZ_MAX), .TABLE_PAIRS(TABLE_PAIRS)) u_rc (
        .clk            (clk_sys),
        .rst            (rst_sys),
        .cfg            (cfg_sys),
        .s_tbl_tdata, .s_tbl_tlast, .s_tbl_tvalid, .s_tbl_tready,
        .s_valid        (se_valid),
        .s_data         (se_data),
        .s_user         (se_user),
        .s_last         (se_last),
        .m_valid        (rc_valid),
        .m_data         (rc_data),
        .m_user         (rc_user),
        .m_last         (rc_last),
        .m_ue           (rc_ue),
        .tbl_cmd, .tbl_rdata, .tbl_done, .tbl_inj, .tbl_ecc,
        .scene_clamped  (fe_status.scene_clamped),
        .scene_replaced (fe_status.scene_replaced),
        .tbl_words      (fe_status.tbl_words)
    );

    corner_turn #(.NX_MAX(NX_MAX), .NZ_MAX(NZ_MAX)) u_ct (
        .clk            (clk_sys),
        .rst            (rst_sys),
        .cfg            (cfg_sys),
        .s_valid        (rc_valid),
        .s_data         (rc_data),
        .s_user         (rc_user),
        .s_last         (rc_last),
        .s_ue           (rc_ue),
        .m_axis_tdata, .m_axis_tuser, .m_axis_scene_ts, .m_axis_ue, .m_axis_fill,
        .m_axis_tlast, .m_axis_tvalid, .m_axis_tready,
        .cnt_clr        (cnt_clr_sys),
        .lines_out      (fe_status.lines_out),
        .dropped_lines  (fe_status.dropped_lines),
        .unfilled_lines (fe_status.unfilled_lines),
        .inj            (ct_inj),
        .ecc            (ct_ecc),
        .tmr_mismatch   (ct_tmr_mismatch)
    );
endmodule
